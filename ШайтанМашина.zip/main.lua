local pfile = io.popen("dir pages /b")
local pages = {}
for l in pfile:lines() do
	table.insert(pages,l)
end
local tfile = io.open("template.html")
local template=tfile:read("*all")
print(template) -- debug
tfile:close()
local index="<ul>"
for i,v in pairs(pages) do
	index=index.. ("<li><a href=\"%s\"><a/>%s</li>"):format(v,v)
end
index=index.."</ul>"
print(index) -- debug
for i,v in pairs(pages) do
	local outfile = io.open("out/"..v..".html","w")
	local content=io.open("pages/"..v)
	local outtext=template
	print(outfile)
	outtext=outtext:gsub("(INDEX)",index)
	outtext=outtext:gsub("(CONTENT)",content:read())
	content:close()
	outfile:write(outtext)
	outfile:close()
end
io.read()